Individual programming test 
1st Semester Computer Science, AP Degree 
 
Test time: 3 hours, 9->12:00
Allowed help: Internet, books, etc. Only human help prohibited, no 
communication during test.

The project holds a JUnit test, what you can use to get immidiate
feedback, if you pass the different test. You may not alter the tests. 
This test holds is a number of sub-assignments. Each sub assignment has 
a number of tests associated with them. 

Test each assignment by right clicking the test folder to test, and
choose "Test".
