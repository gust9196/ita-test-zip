package assignment2;
import java.lang.Math;

public class FlipCoin {

    /**
     * @return a random 0 or 1
     * Value must be random
     */
    public int flipCoin() {

        public static void main (String[] main){
            int coin;
            coin = (int) (Math.random() * 2);
            System.out.println(coin);
        }
    }
}


/*public class FlipCoin {

    public static void main(String[] args) {
        int FlipCoin;
        coin = (int) (Math.random() * 2);
        System.out.println(FlipCoin);
    }
    }
*/
